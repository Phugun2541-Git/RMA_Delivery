# RMA Delivery Mobile Mockup

Prototype สำหรับ review UI ภาษาไทยของแอปมือถือ RMA Delivery: ลูกค้า, ร้านค้า และไรเดอร์/คนขับ; 80 หน้าจอ; hash deep links เช่น `/#/C-06`. Static client-only ไม่มี backend และไม่ใช่โค้ด Flutter.

## Requirements

- Node.js 20 หรือใหม่กว่า
- ไม่ต้องติดตั้ง dependency

## Run locally (Windows PowerShell)

```powershell
# Run from the extracted project folder; replace this example path.
Set-Location "C:\path\to\RMA-Delivery-source"
node .\scripts\build.mjs
node .\scripts\serve.mjs
```

เปิด `http://127.0.0.1:5173/` ใน browser. คงหน้าต่าง PowerShell ไว้ขณะดูเว็บ และกด `Ctrl+C` เพื่อหยุด server. Server ใช้ loopback บนเครื่องนี้เท่านั้น ไม่ใช่ลิงก์สาธารณะ. หากพอร์ต 5173 ถูกใช้อยู่ ให้ตั้ง `$env:PORT = '5174'` ก่อน `node .\scripts\serve.mjs` แล้วเปิด `http://127.0.0.1:5174/`.

ไม่ต้องติดตั้ง dependency. หาก PowerShell บล็อก `npm.ps1` ตาม execution policy ให้ใช้คำสั่ง `node` ด้านบนโดยตรง; ไม่ต้องเปลี่ยน policy. (ถ้าต้องการใช้ npm ให้เรียก `npm.cmd run build` และ `npm.cmd run preview`.) `node .\scripts\build.mjs` สร้าง `dist/` พร้อม `index.html`, `src/` และ `manus-routes.json`. ใน deployment แบบ static ของ Manus จะใช้ committed `dist/` เป็น output โดยไม่ติดตั้ง package.

## Project layout

- `src/data/` — screen registry, flows และข้อมูลสมมติภาษาไทย
- `src/ui/` — auth/customer/merchant/rider/shared renderers และ shared components
- `src/styles/` — tokens light/dark และ responsive app styles
- `scripts/` — static build และ loopback preview server
- `dist/` — production-ready static output ที่สร้างจาก source
- `tokens-draft.md`, `REVIEW-NOTES.md` — เอกสาร review รอบ R1

## Prototype limits

ทุก interaction ใช้ข้อมูลจำลองใน browser. ไม่มี login/OTP จริง, order backend, Smart Kitchen API, payment processing, map/geocoding, file upload, โทรออกหรือแจ้งเตือนจริง. ภาพและ Google Fonts โหลดจาก HTTPS assets; มี CSS placeholder/fallback บางส่วน. ห้ามใช้ตัวเลข/ข้อมูลตัวอย่างเป็นข้อกำหนดธุรกิจ.
