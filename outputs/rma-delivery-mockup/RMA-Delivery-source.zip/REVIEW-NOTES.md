# RMA Delivery — REVIEW NOTES (R1)

วันที่ทำ mockup: 7 ตุลาคม 2569 · ใช้ประชุม review ก่อนล็อก design system/API · อ้างอิง `ai-collab/SCREENS.md` และ `ai-collab/DECISIONS.md`.

## 1. ทิศทางดีไซน์

- **Warm urban utility:** พื้นผิว ivory/slate อุ่น ๆ กับ royal plum-indigo `#5945C7` ให้ความรู้สึกเป็นบริการเมืองที่ไว้ใจได้ และแยกโทนจากเขียว/ส้ม/ชมพูของคู่แข่งตาม brief.
- เน้นอ่านง่ายและทำงานระหว่างมือเดียว/หน้าครัว: ปุ่มเด่น, ราคา/สถานะเห็นชัด, touch target หลักอย่างน้อย 48px; ใช้ลำดับข้อมูลแทนการตกแต่งหนัก.
- ใช้ component, type scale, chip/badge และสี semantic ชุดเดียวกันทุก role; โครงหน้ามือถือฐาน 390px อยู่กับ review rail บน desktop และเต็มจอบนจอเล็ก.
- แผนที่เป็น schematic, bottom sheet ใช้เฉพาะเนื้อหาต่อเนื่อง, snackbar สื่อผลการกระทำ; animation สั้นและเคารพ `prefers-reduced-motion`.
- Light/dark เป็น draft สำหรับ review ไม่ล็อก final; **ไม่มีโลโก้** ตาม D-011 — ใช้ข้อความ “RMA Delivery” เท่านั้น. ภาพอาหารที่ใส่ใน platform project card เป็น thumbnail เพื่อให้ค้นโครงการ ไม่ใช่โลโก้ในแอป.

## 2. ขอบเขตและ flow ที่ครอบคลุม

ทำครบ **80/80 screen IDs** ตาม source list: A 7, C 33, M 17, R 18, S 5; hash route อยู่ใน `/#/<ID>` และมี route manifest 80 หน้า + root.

- เข้าระบบครั้งแรก: A-01 → A-02 → A-03 → A-04 → A-05 → A-07 → C-01.
- ลูกค้าสั่งอาหาร: C-01 → C-04 → C-06 → C-07 → C-08 → C-09 → C-11 → C-12 → C-15.
- ลูกค้าเรียกรถ: C-01 → C-33 → C-35 → C-36 → C-37 → C-38.
- ร้านรับ order: M-04 → M-05 (กำลังทำ → พร้อมส่ง → ส่งมอบไรเดอร์) → M-03.
- ไรเดอร์ส่งอาหาร: R-03 → R-04 → R-05 → R-06 → R-07 → R-08 → R-09.
- งานพ่วงอาหาร: R-05 → R-04 → R-18 → R-06 → R-07 → R-08 → R-09; ลูกค้าเห็นงานแวะใน C-12.
- คนขับรับส่งคน: R-03 → R-04 → R-16 → R-17 → R-09.
- สมัครร้าน/ไรเดอร์ และสลับ role: C-19/A-06 ↔ M-01/M-02, R-01/R-02 และ C-19 ↔ M-17 ↔ R-15.
- กลุ่ม **phase ถัดไป** ติดป้ายตาม source: C-30, C-31, C-32, C-34; C-33 และ C-35–C-38 เป็น flow เรียกรถรับส่งคน MVP.

mock ทุกอย่างอยู่ใน browser: cart/checkout, theme, state, role mode, เมนูขายหมด, order status, chat และ ride/payment response เป็นตัวอย่างในหน้าเว็บเท่านั้น; ไม่มี backend, API, OTP จริง, การโอนเงินจริง, geocoding, Maps SDK หรือ push notification.

## 3. ตารางสมมติฐานที่ทีมต้องเคาะ

| รหัสหน้า | สมมติว่าอะไรใน mockup | ทีมต้องเคาะอะไร |
|---|---|---|
| A-03/A-04 | เบอร์ถูกปิดบางหลัก, OTP ตัวอย่างคือ `123456`, login/LINE ไม่เชื่อม provider; ตัวนับและ resend จำลอง | OTP provider, จำนวนครั้ง/อายุรหัส, lockout, LINE login และ verification policy |
| C-04/C-06/C-09 | ร้านตัวอย่าง 4 ร้าน, ส่ง ฿10, service fee ฿5, minimum order ฿99 สำหรับร้านหลัก | ระยะ/โซนส่ง, minimum, วิธีคิด service fee, ภาษีและร้านที่อยู่นอก Smart Kitchen |
| C-10/C-11/C-14 | โค้ด RMA40 ลด 20% สูงสุด ฿40 เมื่อครบ ฿150; ส่งฟรีลด ฿15; มี PromptPay/บัตร/เงินสดเป็นภาพจำลอง; คืนเงิน 3–5 วันทำการ | วิธีชำระจริง, เก็บเงินสด/เก็บปลายทาง, เงื่อนไขโค้ด, ยกเลิกได้ถึงสถานะไหน, ใครรับผิดชอบค่าธรรมเนียม/คืนเงินและ SLA |
| C-35/C-38 | ตัวอย่างรถ/ราคา/จำนวนที่นั่ง/ETA: มอเตอร์ไซค์ 1 ที่ ฿42/3 นาที; รถประหยัด 4 ที่ ฿86/6 นาที; รถใหญ่ 6 ที่ ฿125/9 นาที; พรีเมียม 4 ที่ ฿174/8 นาที | ชนิดรถและราคาในพื้นที่, dynamic pricing, จำนวนสัมภาระ/คน, ค่ารอ/ยกเลิก, คูปอง, วิธีคิดราคาสุดท้าย |
| C-36/C-37/R-16/R-17 | หา/พบคนขับ, ETA, จุดรับ, การโทร/ฉุกเฉินเป็น state จำลอง; ค่าโดยสารตัวอย่างคนขับ/ผู้โดยสาร ฿86 | matching timeout, safety/insurance, การแชร์ trip, SOP ฉุกเฉินและช่องทางจริง, no-show และ waiting fee |
| M-04/M-11/M-12 | ร้านมีเวลา accept 45 วินาที, รอบโอนอังคาร/ศุกร์; ตัวอย่าง platform fee 15% | เวลารับ order จริง, commission/fee และฐานคำนวณ, payout cut-off, VAT/เอกสารบัญชี, เงื่อนไขร้านปิด |
| M-10/M-06 | ร้านหลัก sync 18 เมนูจาก Smart Kitchen และสต็อกอัปเดตแบบจำลอง | วิธีผูก account, API/event contract, authoritative source ของเมนู/ราคา/stock, retry/idempotency, วิธีจัดการร้านที่ไม่มี POS |
| R-04/R-18/C-12 | งานพ่วงเพิ่ม 1.4 กม., 8 นาที, ค่าตอบแทน +฿18; ตัวอย่างระบุสูงสุด 2 order | รัศมี/พื้นที่ที่อนุญาต, จำนวนงานพ่วงสูงสุด, คำนวณรายได้, ปฏิเสธได้หรือไม่ และสื่อ ETA ให้ลูกค้าอย่างไร |
| R-05/R-06/R-07/R-08 | ส่งอาหารด้วยมอเตอร์ไซค์; ค่าตอบแทนตัวอย่าง ฿52 + ทิป; เลขรถ/บุคคลเป็นข้อมูลแต่งขึ้น | สูตรรายได้และ incentive, proof-of-delivery, handling เงินสด, dispute และเอกสารคนขับตาม D-016 |
| R-03/R-16/R-17 | เลือกประเภทที่พร้อมรับทีละแบบ; ระหว่างรับส่งคนไม่มีงานเข้า; ระหว่างส่งอาหารอาจรับเฉพาะงานพ่วงอาหาร ตาม D-014 | วิธี enforce ที่ backend และ race conditions ตอนมี event/offer ค้างขณะสลับประเภทงาน |
| C-30/C-31/C-32/C-34 | สร้างงานส่งของและบริการ (ซ่อมแอร์/แม่บ้าน) เป็นภาพอนาคต; ตัวอย่างยังไม่สร้างธุรกรรม | catalog, ขอบเขตงาน, ราคา, cancellation, การจอง/ผู้ให้บริการ และ release criteria ของ phase ถัดไป |
| ทุก role | ชื่อลูกค้า/ร้าน/ไรเดอร์, เบอร์, ที่อยู่, เลขทะเบียน, bank account, รีวิว, order และยอดรายงานเป็นข้อมูลสมมติ; theme เก็บใน localStorage | เปลี่ยน fixtures ก่อนสาธิตต่อภายนอก; ยืนยัน privacy copy, profile consent และ data retention ใน product จริง |

> ตัวเลขค่าตอบแทน/ค่าธรรมเนียม/ราคาในตารางเป็น **สมมติฐานเพื่อให้ review เห็นภาพเท่านั้น** ไม่ใช่คำมั่นหรือข้อกำหนดธุรกิจ.

## 4. เทียบรายการหน้า

- **เพิ่ม:** ไม่มี.
- **รวม:** ไม่มี.
- **เสนอให้ตัด:** ไม่มี.
- รักษารหัสเดิมครบ 80 หน้าและคง gap `C-25`–`C-29` ตาม source; ไม่สร้างรหัสทดแทน. ป้าย phase ของ C-30/31/32/34 สอดคล้อง `SCREENS.md`; C-33 เป็น MVP.

## 5. Bottom navigation และสลับ role

| Role | 5 แท็บ | เหตุผล |
|---|---|---|
| ลูกค้า | หน้าหลัก C-01 · ร้านอาหาร C-04 · รายการ C-16 · ข้อความ C-18 · บัญชี C-19 | เข้าถึงการค้นร้าน, ประวัติ/ติดตาม, การสื่อสารและข้อมูลส่วนตัวโดยตรง |
| ร้านค้า | ออเดอร์ M-03 · เมนู M-06 · รายงาน M-13 · ช่วยเหลือ M-16 · บัญชี M-17 | ให้การรับ/จัดการ order เป็นจุดแรก; เมนูและยอดขายอยู่ใกล้มือ; บัญชี/Smart Kitchen อยู่รวมในหน้าร้าน |
| ไรเดอร์ | แผนที่ R-03 · งาน R-10 · รายได้ R-11 · รายงาน R-12 · บัญชี R-15 | เน้นความพร้อมออนไลน์/พื้นที่, งาน, รายได้ และเอกสารรถ; จำกัด 5 แท็บตาม brief |

ปุ่ม `⋯` มุมขวาบนเปิดหน้าบัญชีของ role ปัจจุบัน (C-19/M-17/R-15); ปุ่ม “สลับ role” บนหน้าบัญชีไป A-06. เหตุผล: ลดการสลับผิดระหว่างกำลังทำงาน และทำให้ผู้ใช้เห็น context ก่อนเปลี่ยน. Review rail เป็นทางลัด reviewer อีกเส้นหนึ่ง ไม่ใช่การสลับข้อมูลบัญชีจริง.

## 6. คำถามสำหรับ review

### ถึง Claude — เทคนิค/API
1. API ownership และ state transition/event contract ของ order ตั้งแต่ Smart Kitchen → Delivery → rider → customer คืออะไร; สถานะไหนเป็น source of truth?
2. Smart Kitchen sync: วิธี auth/bind ร้าน, menu/stock change event, retry และ conflict behavior ที่ backend รองรับมีอะไรบ้าง?
3. API ต้องแยก rider task type/active job อย่างไรเพื่อ enforce D-014 และป้องกันงานชนกัน; job bundle payload รวม ETA/ค่าตอบแทนอย่างไร?
4. Navigation/deep-link route ID จาก 80 mock screens ควร map เป็น Flutter route/feature boundaries อย่างไร; `C-30`–`C-34` จะ version/gate phase อย่างไร?
5. Payment/cancellation/refund API, callback idempotency, delivery fee, commission และ role-specific session/permission contract ที่ต้องส่งให้ frontend มีอะไรบ้าง?

### ถึงเจ้าของ — ธุรกิจ/การปฏิบัติงาน
1. ยืนยันค่าธรรมเนียมร้าน, ค่าส่ง/service fee, รอบโอน, payment channels, cash collection และ refund timeline.
2. เคาะ vehicle catalog, fare/ETA, wait/no-show/cancel fees, seat/luggage policy และมาตรฐาน safety/ฉุกเฉิน.
3. เคาะระยะ/พื้นที่และจำนวนงานพ่วงสูงสุด, extra compensation/ETA, accept timeout และกติกาปฏิเสธ.
4. ยืนยันข้อมูล/เอกสารสมัครร้านและคนขับ (โดยเฉพาะรายการจริงตาม D-016), การอนุมัติและเวลารอ.
5. กำหนด Smart Kitchen contract และ onboarding ร้านที่ไม่มี Smart Kitchen; ใครเป็นเจ้าของราคา/สต็อก.
6. ระบุขอบเขต catalog/ผู้ให้บริการ/การจองของส่งของและบริการก่อนเริ่ม phase ต่อไป.
7. เมื่อชื่อผลิตภัณฑ์เคาะแล้ว ค่อยตัดสิน brand/logo; รอบนี้ใช้ placeholder ตาม D-011.

## 7. ขอบเขตการตรวจ

- Smoke-render ทุก screen ID และ state fixtures, build static output, ตรวจ 80 hash routes จาก source; ทดสอบ click-flow/หน้าสำคัญบน browser หลัง publish.
- Asset ภาพอาหารใช้ URL ที่ค้นมาและมี CSS gradient fallback; ต้องตรวจสิทธิ/เลือกภาพ production ที่อนุญาตก่อนเผยแพร่แอปจริง. Google Fonts ต้องมี network; system fallback อยู่ใน stack.
- ไม่มีข้อมูล/การชำระเงินจริงหรือ API. ปุ่มโทร/นำทาง/อัปโหลด/ฉุกเฉินและการกรอกบางส่วนเป็น prototype response; อย่าใช้แทนระบบ production.

## 8. สถานะ QA และ handoff

- `node --check` ผ่านทุกโมดูล; smoke render ผ่าน **80/80 หน้าจอ และ 50/50 state variants**; static build ได้ 81 routes (root + 80 deep links).
- Token audit เทียบ CSS variables กับ draft ครบ 23 color tokens; ตรวจ 38 คู่สีของ Light/Dark, คู่ต่ำสุด **4.91:1**. เป็นการตรวจ token pairs ไม่ใช่ WCAG audit ทั้งผลิตภัณฑ์.
- Browser spot-check ก่อน final refinements ทำไว้บาง flow; post-refinement browser pass ยังไม่ครบ เพราะ local preview process รายงานทำงานแต่ไม่มี listener บนพอร์ต 5173 หลังตรวจซ้ำ. หยุดการ restart ซ้ำ; local loopback URL ยังไม่ใช่ลิงก์ส่ง review.
- Publish **ยังไม่สำเร็จ**: `git fetch manus` ผ่าน Managed Git ล้มเหลวด้วย Windows Schannel `SEC_E_NO_CREDENTIALS`; ไม่มี checkpoint/remote commit จึงยังไม่มี permanent URL. Static `dist/` และ build config พร้อมแล้ว. เมื่อ Git credential ของ WebDev ใช้งานได้ จึง fetch/ตรวจ canonical main, checkpoint, publish และตรวจ public URL ต่อ; ห้ามอ้าง sandbox URL แทน.


### Follow-up: credential helper diagnosis (7 ตุลาคม 2569)

- `GET config` ยืนยัน provider เป็น Manus, static build ใช้ `dist/`, `auto_publish=false`, และยังไม่มี live deployment; project `secrets` ว่างเป็นค่าของแอป ไม่ใช่หลักฐานสถานะ Managed Git credentials.
- การ fetch ปกติให้ `SEC_E_NO_CREDENTIALS`. การทดสอบ TLS backend แบบชั่วคราวครั้งเดียวเปิดเผยว่า Git เรียก `__addon_git_credential` ไม่สำเร็จ (`Permission denied`); จากนั้น fallback ต้องใช้ `/dev/tty` ซึ่งไม่มีใน command host จึงอ่าน username ไม่ได้. นี่ชี้ไปที่การ launch/permission boundary ของ Host credential helper มากกว่าพิสูจน์ว่า password/token ของบัญชีผิด.
- ไม่มีการอ่าน แสดง หรือขอ credential value และหยุด retry หลังผล permission error. เมื่อ Manus Desktop/WebDev credential helper ใช้งานได้ ให้ fetch และตรวจ canonical main ผ่าน Managed Git, ทำ checkpoint แล้วเรียก one-time publish; ไม่ต้องส่ง credential ทางแชต.
- `GET logs?type=system` ตอบ `not_applicable` เพราะยังไม่มี deployment; จึงไม่มี production logs ให้ตรวจ.